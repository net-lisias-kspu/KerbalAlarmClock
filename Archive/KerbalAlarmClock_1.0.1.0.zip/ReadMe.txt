KerbalAlarmClock - 1.0.0.0
--------------------------
How to stop Jeb from flying past his destination at Warp speed.

By Trigger Au

INSTALLATION
Copy the folders to the KSP application.

TROUBLESHOOTING
The plugin records troubleshooting data in the "KSP_Data\outut_log.txt".
If there are errors in loading the config you can delete the "\PluginData\kerbalalarmclock\config.xml" and restart the game

VERSION HISTORY
Version 1.0.0.0
-Initial Release
-Allows for creating Raw Alarms
-Allows for creating Alarms based on Manuever Nodes