KerbalAlarmClock - 1.2.0.0
--------------------------
How to stop Jeb from flying past his destination at Warp speed.

By Trigger Au

Forum Thread for latest: http://forum.kerbalspaceprogram.com/showthread.php/43666-Kerbal-Alarm-Clock

INSTALLATION
******************* NOTE  ******************* NOTE ******************* NOTE *******************
IF YOU WANT TO MAINTAIN YOUR SAVED ALARMS DO NOT COPY THE CONFIG.XML FILE OVER
******************* NOTE  ******************* NOTE ******************* NOTE *******************
Copy the folders to the KSP application.

TROUBLESHOOTING
The plugin records troubleshooting data in the "KSP_Data\outut_log.txt".
If there are errors in loading the config you can delete the "\PluginData\kerbalalarmclock\config.xml" and restart the game

VERSION HISTORY
Version 1.2.0.0
- Resolved a few more GUI Issues
- Added Web update check
- Added Settings Pane with a few global options
- Added Sphere of Influence Change detection
- Added Ability to work in UT as well as days,hours
- Added Pause on alarm option
- Added configurable scrolling view of alarms
- Added View/Edit capability to existing Alarms

Version 1.0.1.0
-Resolved some GUI Issues

Version 1.0.0.0
-Initial Release
-Allows for creating Raw Alarms
-Allows for creating Alarms based on Manuever Nodes